<?php echo e($slot); ?>

<?php /**PATH /var/www/html/gig-todo/resources/views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>