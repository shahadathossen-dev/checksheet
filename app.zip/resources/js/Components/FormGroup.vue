<template>
	<div class="flex flex-col md:flex-row w-full px-4 py-2">
		<slot></slot>
	</div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
</style>
