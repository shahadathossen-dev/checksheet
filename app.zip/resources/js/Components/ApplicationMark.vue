<template>
    <img class="max-w-full" src="../../images/logo-mark.png" alt="{{ env('APP_NAME') }}" />
</template>
